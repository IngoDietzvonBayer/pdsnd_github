Not realy much in hear.
All necesarry comments (keept brief) are in the code.
Besides the Pandas documetation no other sources were used.